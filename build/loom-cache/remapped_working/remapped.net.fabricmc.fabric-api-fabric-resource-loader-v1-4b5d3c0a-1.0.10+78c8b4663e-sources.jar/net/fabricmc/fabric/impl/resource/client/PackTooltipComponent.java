/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.client;

import java.util.List;
import java.util.Optional;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.item.tooltip.TooltipData;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public record PackTooltipComponent(Optional<Text> name, Optional<List<OrderedText>> description)
		implements TooltipData, TooltipComponent {
	@Override
	public int getHeight(TextRenderer font) {
		int height = 0;

		if (this.name.isPresent()) {
			height += font.fontHeight + 2;
		}

		if (this.description.isPresent()) {
			height += this.description.get().size() * font.fontHeight + 3;
		}

		if (this.name.isPresent() && this.description.isPresent()) {
			height += font.fontHeight;
		}

		return height;
	}

	@Override
	public int getWidth(TextRenderer font) {
		return Math.max(
				this.name.map(font::getWidth).orElse(0),
				this.description
						.map(description -> description.stream().mapToInt(font::getWidth).max().orElse(0))
						.orElse(0)
		);
	}

	@Override
	public void drawText(DrawContext graphics, TextRenderer font, int x, int y) {
		if (this.name.isPresent()) {
			graphics.drawText(font, this.name.get(), x, y, 0xffffffff, true);
			y += font.fontHeight + 1;

			if (this.description.isPresent()) {
				y += font.fontHeight;
			}
		}

		if (this.description.isPresent()) {
			for (OrderedText line : this.description.get()) {
				graphics.drawText(font, line, x, y, 0xffffffff, true);
				y += font.fontHeight + 1;
			}
		}
	}

	@Override
	public void drawItems(TextRenderer font, int x, int y, int width, int height, DrawContext graphics) {
		if (this.name.isPresent() && this.description.isPresent()) {
			graphics.fill(
					x, y + font.fontHeight + 4,
					x + this.getWidth(font), y + font.fontHeight + 5,
					0xff000000 | Formatting.GRAY.getColorValue()
			);
		}
	}
}
